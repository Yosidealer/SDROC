//Dit is een applicatie voor de eindopdracht Inleiding Programmeren ROC Flevoland 2025.

//naam: Zero Legacy (Processing Java Demo 1.0)

//Dit is een kleine demo remake van een spel wat ik vroeger had gemaakt toen ik jong
//was met Scratch (blokkencode). De oude Scratch versie is in vergelijking met dit
//veel meer geadvanceerd met hele storyline en weet ik veel wat, dit is een kleine demo
//remake nogmaals. Maar ik ben super trots op deze mini demo en hoop dat ik het spel
//ooit echt helemaal kan hermaken.


//Ik heb dit gebouwd met behulp van het internet, code is zelf geschreven maar ik heb
//online dingen opgezocht wat en hoe ik dat moet doen, in mijn hoofd zit weet ik nou
//niet of ik hiermee gecheat hebt en het maar van het internet gekopieerd hebt, maar
//ik denk en hoop van niet want ik heb hier van dit project wel heel veel van geleerd.


//dussehhhh.... ja enjoy :D


-


(dit staat ook in ZeroLegacy_ProcessingJavaDemo1_.pde)